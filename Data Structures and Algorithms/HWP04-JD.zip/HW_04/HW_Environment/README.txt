-Compiled with the command line in windows below
"g++ *.cpp -o main.exe -std=c++11"

-Information regarding file names
	- Assignment4_MyStackADT.cpp = source cpp file
	- main.exe = executable for program for Windows
	- myQueueADT.cpp = class file
	- myQueueADT.h = header file for class above
	- recFile.txt...txt = Stream input/output file