-Compiled with the command line in windows below
"c++ *.cpp -o main.exe -std=c++11"

-Information regarding file names
	- .DS_Store = macOS file because I switch between OS systems a lot
	- Assignment 1 - Template.cpp = source cpp file
	- main.exe = executable for program
	- MyUtilityClass.cpp = class file
	- myUtilityClass.h = header file for class above
	- output.txt = Write files for the writing option
	- read.txt = sample reading files
	- recFile = Stream input/output file