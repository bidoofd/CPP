-Compiled with the command line in windows below
"c++ *.cpp -o main.exe -std=c++11"

-Information regarding file names
	- .DS_Store = macOS file because I switch between OS systems a lot
	- Assignment 2 - LIST ADT.cpp = source cpp file
	- main.exe = executable for program for Windows
	- myListADT.cpp = class file
	- myListADT.h = header file for class above
	- recFile = Stream input/output file